/**
 * Library Management System - Express Backend
 * Port: 5000
 * 
 * Routes:
 *   GET/POST/PUT/DELETE /api/books
 *   GET/POST/PUT/DELETE /api/students
 *   GET/POST           /api/transactions/issue, /api/transactions/return
 *   GET                /api/transactions, /api/transactions/active
 *   GET                /api/dashboard
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const { initializeDatabase } = require('./database/db');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize SQLite database (seeds from existing JSON if empty)
try {
  initializeDatabase();
} catch (err) {
  console.error('[FATAL] Database initialization failed:', err);
  process.exit(1);
}

// Routes
app.use('/api/books', require('./routes/books'));
app.use('/api/students', require('./routes/students'));
app.use('/api/transactions', require('./routes/transactions'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/system', require('./routes/system'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'Library Management System API is running.', timestamp: new Date().toISOString() });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, error: `Route '${req.path}' not found.` });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('[Server Error]', err);
  res.status(500).json({ success: false, error: 'An unexpected server error occurred.' });
});

app.listen(PORT, () => {
  console.log(`\n========================================`);
  console.log(`  Library Management System - Backend`);
  console.log(`  Running at: http://localhost:${PORT}`);
  console.log(`  API Base:   http://localhost:${PORT}/api`);
  console.log(`========================================\n`);
});

module.exports = app;
