const express = require('express');
const router = express.Router();
const { issueBook, returnBook, getAllTransactions, getActiveTransactions, getTransactionById } = require('../controllers/transactionsController');

router.get('/', getAllTransactions);
router.get('/active', getActiveTransactions);
router.get('/:id', getTransactionById);
router.post('/issue', issueBook);
router.post('/return', returnBook);

module.exports = router;
