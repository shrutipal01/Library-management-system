const express = require('express');
const router = express.Router();
const { resetDatabase, runDiagnostics } = require('../controllers/systemController');

router.post('/reset', resetDatabase);
router.get('/diagnostics', runDiagnostics);

module.exports = router;
