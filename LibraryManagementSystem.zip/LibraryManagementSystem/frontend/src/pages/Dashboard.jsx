import { useState, useEffect } from 'react';
import { api } from '../services/api';

export default function Dashboard({ onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getDashboard();
      setStats(res.data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <div className="loading"><div className="spinner"></div>Loading dashboard...</div>;
  if (error) return <div className="alert alert-error">⚠️ {error}</div>;
  if (!stats) return null;

  const availability = stats.total_books_stock > 0
    ? Math.round((stats.total_available_stock / stats.total_books_stock) * 100)
    : 0;

  return (
    <div>
      <div className="page-header">
        <h1>📊 Dashboard</h1>
        <p>Real-time overview of Central University MCA Library</p>
      </div>

      {/* Stat Cards */}
      <div className="stats-grid">
        <div className="stat-card blue">
          <div className="stat-icon blue">📚</div>
          <div className="stat-info">
            <div className="stat-value">{stats.total_titles}</div>
            <div className="stat-label">Total Book Titles</div>
            <div className="stat-sub">{stats.total_books_stock} total volumes</div>
          </div>
        </div>
        <div className="stat-card green">
          <div className="stat-icon green">✅</div>
          <div className="stat-info">
            <div className="stat-value">{stats.total_available_stock}</div>
            <div className="stat-label">Available Copies</div>
            <div className="stat-sub">{availability}% availability</div>
          </div>
        </div>
        <div className="stat-card amber">
          <div className="stat-icon amber">📤</div>
          <div className="stat-info">
            <div className="stat-value">{stats.total_currently_issued}</div>
            <div className="stat-label">Currently Issued</div>
            <div className="stat-sub">{stats.active_transactions} active loans</div>
          </div>
        </div>
        <div className="stat-card purple">
          <div className="stat-icon purple">👥</div>
          <div className="stat-info">
            <div className="stat-value">{stats.total_students}</div>
            <div className="stat-label">Registered Members</div>
            <div className="stat-sub">{stats.active_borrowers} active borrowers</div>
          </div>
        </div>
        <div className="stat-card red">
          <div className="stat-icon red">⏰</div>
          <div className="stat-info">
            <div className="stat-value">{stats.overdue_count}</div>
            <div className="stat-label">Overdue Books</div>
            <div className="stat-sub">Require immediate return</div>
          </div>
        </div>
        <div className="stat-card teal">
          <div className="stat-icon teal">💰</div>
          <div className="stat-info">
            <div className="stat-value">₹{stats.total_fines_collected?.toFixed(0)}</div>
            <div className="stat-label">Fines Collected</div>
            <div className="stat-sub">Avg ₹{stats.avg_fine?.toFixed(1)} per overdue</div>
          </div>
        </div>
      </div>

      {/* Inventory Progress */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
        <div className="card">
          <div className="card-header">
            <span className="card-title">📚 Top 5 Most Popular Books</span>
          </div>
          <div className="card-body">
            {stats.top_books?.length > 0 ? (
              <div className="chart-bar-horiz">
                {stats.top_books.map((book, i) => {
                  const max = stats.top_books[0].issue_count || 1;
                  const pct = Math.max(8, (book.issue_count / max) * 100);
                  return (
                    <div key={book.book_id} className="chart-bar-item">
                      <span className="chart-bar-label" title={book.title}>
                        {i + 1}. {book.title.length > 20 ? book.title.slice(0, 20) + '…' : book.title}
                      </span>
                      <div className="chart-bar-track">
                        <div className="chart-bar-fill" style={{ width: `${pct}%` }}>
                          <span className="chart-bar-value">{book.issue_count}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : <div className="empty-state"><p>No book data available</p></div>}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">📖 Genre Distribution</span>
          </div>
          <div className="card-body">
            {stats.genre_distribution?.length > 0 ? (
              <div className="chart-bar-horiz">
                {stats.genre_distribution.slice(0, 6).map(g => {
                  const max = stats.genre_distribution[0].count || 1;
                  const pct = Math.max(8, (g.count / max) * 100);
                  return (
                    <div key={g.genre} className="chart-bar-item">
                      <span className="chart-bar-label" title={g.genre}>
                        {g.genre}
                      </span>
                      <div className="chart-bar-track">
                        <div className="chart-bar-fill" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #8b5cf6, #ec4899)' }}>
                          <span className="chart-bar-value">{g.count}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : <div className="empty-state"><p>No data</p></div>}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Recent Transactions */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">🔄 Recent Transactions</span>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('transactions')}>View All →</button>
          </div>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Book</th>
                  <th>Member</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.recent_transactions?.length > 0 ? stats.recent_transactions.map(t => (
                  <tr key={t.txn_id}>
                    <td style={{ maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.book_title}</td>
                    <td>{t.student_name}</td>
                    <td>
                      <span className={`badge ${t.status === 'ISSUED' ? 'badge-issued' : 'badge-returned'}`}>{t.status}</span>
                    </td>
                    <td className="td-mono">{t.issue_date}</td>
                  </tr>
                )) : (
                  <tr><td colSpan={4} className="empty-state"><p>No transactions yet</p></td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary Stats + Dept Distribution */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {/* Analytics Summary */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">📈 NumPy Analytics</span>
            </div>
            <div className="card-body">
              <div className="detail-grid">
                <div className="detail-item">
                  <div className="detail-label">Total Transactions</div>
                  <div className="detail-value">{stats.total_transactions}</div>
                </div>
                <div className="detail-item">
                  <div className="detail-label">Lifetime Issues</div>
                  <div className="detail-value">{stats.total_lifetime_issues}</div>
                </div>
                <div className="detail-item">
                  <div className="detail-label">Mean Issues/Book</div>
                  <div className="detail-value">{stats.mean_issues_per_book?.toFixed(1)}</div>
                </div>
                <div className="detail-item">
                  <div className="detail-label">Median Issues/Book</div>
                  <div className="detail-value">{stats.median_issues_per_book?.toFixed(1)}</div>
                </div>
                <div className="detail-item">
                  <div className="detail-label">Max Fine</div>
                  <div className="detail-value" style={{ color: 'var(--color-danger)' }}>₹{stats.max_fine?.toFixed(0)}</div>
                </div>
                <div className="detail-item">
                  <div className="detail-label">Inventory Use</div>
                  <div className="detail-value">{100 - availability}% issued</div>
                </div>
              </div>
              <div style={{ marginTop: '14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--color-text-muted)', marginBottom: '6px' }}>
                  <span>Available: {stats.total_available_stock}</span>
                  <span>Issued: {stats.total_currently_issued}</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-bar-fill" style={{ width: `${availability}%`, background: 'linear-gradient(90deg, #10b981, #3b82f6)' }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Dept distribution */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">🎓 Members by Dept</span>
            </div>
            <div className="card-body" style={{ paddingTop: '12px' }}>
              {stats.dept_distribution?.length > 0 ? (
                <div className="chart-bar-horiz">
                  {stats.dept_distribution.map(d => {
                    const max = stats.dept_distribution[0].count || 1;
                    const pct = Math.max(8, (d.count / max) * 100);
                    return (
                      <div key={d.department} className="chart-bar-item">
                        <span className="chart-bar-label">{d.department}</span>
                        <div className="chart-bar-track">
                          <div className="chart-bar-fill" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #f59e0b, #ef4444)' }}>
                            <span className="chart-bar-value">{d.count}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : <div className="empty-state"><p>No data</p></div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
