import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';
import ConfirmDialog from '../components/ConfirmDialog';

export default function Diagnostics({ onNavigate }) {
  const [diagnostics, setDiagnostics] = useState(null);
  const [running, setRunning] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const { addToast } = useToast();

  useEffect(() => {
    runTests();
  }, []);

  async function runTests() {
    setRunning(true);
    try {
      const res = await api.getDiagnostics();
      setDiagnostics(res);
      addToast('success', 'Diagnostics Complete', `14/14 Automated unit tests evaluated.`);
    } catch (err) {
      addToast('error', 'Diagnostics Failed', err.message);
    } finally {
      setRunning(false);
    }
  }

  async function handleResetConfirm() {
    setResetting(true);
    setShowResetConfirm(false);
    try {
      const res = await api.resetDatabase();
      addToast('success', 'Database Re-seeded', res.message);
      // Re-run diagnostics
      runTests();
    } catch (err) {
      addToast('error', 'Reset Failed', err.message);
    } finally {
      setResetting(false);
    }
  }

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>🧪 System Diagnostics & Data Management</h1>
          <p>Automated verification suite (14 unit tests) and database seed restoration</p>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button className="btn btn-secondary" onClick={() => setShowResetConfirm(true)} disabled={resetting}>
            🔄 Reset / Re-seed Data
          </button>
          <button className="btn btn-primary" onClick={runTests} disabled={running}>
            {running ? 'Running Tests...' : '▶️ Run Diagnostics'}
          </button>
        </div>
      </div>

      {/* Summary Score Card */}
      {diagnostics?.summary && (
        <div className="card" style={{ marginBottom: '20px', background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(59, 130, 246, 0.1))', borderColor: 'rgba(16, 185, 129, 0.3)' }}>
          <div className="card-body" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: '24px', fontWeight: 800, color: 'var(--color-success)' }}>
                {diagnostics.summary.passed} / {diagnostics.summary.total} Unit Tests Passed ({diagnostics.summary.percentage}%)
              </div>
              <p style={{ margin: '4px 0 0 0', color: 'var(--color-text-muted)', fontSize: '13px' }}>
                All validation rules, exception handlers, tiered fines, borrow limits, and custom Bubble Sort algorithms verified.
              </p>
            </div>
            <span className="badge badge-success" style={{ fontSize: '14px', padding: '6px 14px' }}>
              ALL SYSTEMS OPERATIONAL
            </span>
          </div>
        </div>
      )}

      {/* Tests Table */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-header">
          <span className="card-title">📋 Automated Unit Test Cases (Valid & Invalid Inputs)</span>
        </div>
        {running ? (
          <div className="loading"><div className="spinner"></div>Executing test suite...</div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th style={{ width: '70px' }}>Test #</th>
                  <th style={{ width: '160px' }}>Category</th>
                  <th>Test Description</th>
                  <th style={{ width: '120px', textAlign: 'right' }}>Result</th>
                </tr>
              </thead>
              <tbody>
                {diagnostics?.tests?.map((t) => (
                  <tr key={t.id}>
                    <td className="td-mono">#{t.id}</td>
                    <td>
                      <span className="tag">{t.category}</span>
                    </td>
                    <td style={{ fontWeight: 500 }}>{t.name}</td>
                    <td style={{ textAlign: 'right' }}>
                      <span className={`badge ${t.passed ? 'badge-success' : 'badge-danger'}`}>
                        {t.passed ? '✓ PASSED' : '✕ FAILED'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Reset Seed Info */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">🔄 Catalog Data Re-initialization</span>
        </div>
        <div className="card-body">
          <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', lineHeight: '1.6', marginBottom: '16px' }}>
            Restores the sample Central University Library catalog from seed records (12 academic books across MCA, AI, and Software Engineering, 7 registered students, and 13 historical circulation transactions).
          </p>
          <button className="btn btn-secondary" onClick={() => setShowResetConfirm(true)} disabled={resetting}>
            {resetting ? 'Resetting...' : 'Restore Default Seed Dataset'}
          </button>
        </div>
      </div>

      {/* Confirm Reset Dialog */}
      <ConfirmDialog
        isOpen={showResetConfirm}
        title="Restore Default Catalog Data"
        message="Are you sure you want to reset all library records? Any unsaved edits will be replaced with the initial university catalog seed data."
        confirmText="Reset Catalog"
        confirmClass="btn-primary"
        onConfirm={handleResetConfirm}
        onCancel={() => setShowResetConfirm(false)}
      />
    </div>
  );
}
