import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';

export default function Transactions({ onNavigate }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterTab, setFilterTab] = useState('all'); // 'all', 'active', 'overdue', 'returned'
  const [search, setSearch] = useState('');

  const { addToast } = useToast();

  useEffect(() => {
    loadTransactions();
  }, [filterTab, search]);

  async function loadTransactions() {
    setLoading(true);
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (filterTab === 'active') params.status = 'ISSUED';
      if (filterTab === 'returned') params.status = 'RETURNED';

      const res = await api.getTransactions(params);
      let list = res.data || [];

      if (filterTab === 'overdue') {
        const today = new Date().toISOString().split('T')[0];
        list = list.filter(t => t.status === 'ISSUED' && t.due_date < today);
      }

      setTransactions(list);
    } catch (err) {
      addToast('error', 'Failed to load transactions', err.message);
    } finally {
      setLoading(false);
    }
  }

  const today = new Date().toISOString().split('T')[0];

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>🔄 Circulation Records & Transactions</h1>
          <p>Complete historical ledger of book loans, returns, active loans, and fine settlements</p>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button className="btn btn-secondary" onClick={() => onNavigate('return')}>
            📥 Return Desk
          </button>
          <button className="btn btn-primary" onClick={() => onNavigate('issue')}>
            📤 Issue Desk
          </button>
        </div>
      </div>

      {/* Tabs and Search */}
      <div className="card" style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', justifyContent: 'space-between', alignItems: 'center' }}>
          {/* Tabs */}
          <div style={{ display: 'flex', gap: '6px' }}>
            <button
              className={`btn ${filterTab === 'all' ? 'btn-primary' : 'btn-ghost'} btn-sm`}
              onClick={() => setFilterTab('all')}
            >
              All Records
            </button>
            <button
              className={`btn ${filterTab === 'active' ? 'btn-primary' : 'btn-ghost'} btn-sm`}
              onClick={() => setFilterTab('active')}
            >
              Active Loans (Issued)
            </button>
            <button
              className={`btn ${filterTab === 'overdue' ? 'btn-danger' : 'btn-ghost'} btn-sm`}
              onClick={() => setFilterTab('overdue')}
            >
              ⚠️ Overdue Only
            </button>
            <button
              className={`btn ${filterTab === 'returned' ? 'btn-primary' : 'btn-ghost'} btn-sm`}
              onClick={() => setFilterTab('returned')}
            >
              Returned
            </button>
          </div>

          {/* Search bar */}
          <div style={{ width: '280px' }}>
            <input
              type="text"
              placeholder="Search txn, book, or student..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              id="input-txn-search"
            />
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">
            Ledger Records ({transactions.length})
          </span>
        </div>

        {loading ? (
          <div className="loading"><div className="spinner"></div>Loading transactions...</div>
        ) : transactions.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🔄</div>
            <h3>No transactions found</h3>
            <p>No transactions match the selected filter or search query.</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th style={{ width: '90px' }}>Txn ID</th>
                  <th>Book Title</th>
                  <th>Student Name</th>
                  <th style={{ width: '100px' }}>Issue Date</th>
                  <th style={{ width: '100px' }}>Due Date</th>
                  <th style={{ width: '100px' }}>Return Date</th>
                  <th style={{ width: '100px' }}>Status</th>
                  <th style={{ width: '90px', textAlign: 'right' }}>Fine (₹)</th>
                  <th style={{ width: '110px', textAlign: 'right' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((t) => {
                  const isOverdue = t.status === 'ISSUED' && t.due_date < today;
                  return (
                    <tr key={t.txn_id} style={{ background: isOverdue ? 'rgba(239, 68, 68, 0.05)' : 'transparent' }}>
                      <td className="td-mono">{t.txn_id}</td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{t.book_title}</div>
                        <div className="td-mono" style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{t.book_id}</div>
                      </td>
                      <td>
                        <div>{t.student_name}</div>
                        <div style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>
                          <span className="td-mono">{t.student_id}</span> • {t.student_department}
                        </div>
                      </td>
                      <td className="td-mono">{t.issue_date}</td>
                      <td className="td-mono" style={{ color: isOverdue ? 'var(--color-danger)' : 'inherit', fontWeight: isOverdue ? 700 : 'normal' }}>
                        {t.due_date}
                      </td>
                      <td className="td-mono">
                        {t.return_date || <span style={{ color: 'var(--color-text-dim)' }}>—</span>}
                      </td>
                      <td>
                        <span className={`badge ${isOverdue ? 'badge-danger' : t.status === 'ISSUED' ? 'badge-issued' : 'badge-returned'}`}>
                          {isOverdue ? 'OVERDUE' : t.status}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right', fontWeight: 600, color: t.fine_amount > 0 ? 'var(--color-danger)' : 'inherit' }}>
                        ₹{t.fine_amount ? t.fine_amount.toFixed(2) : '0.00'}
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        {t.status === 'ISSUED' ? (
                          <button
                            className="btn btn-ghost btn-sm"
                            title="Return this book"
                            onClick={() => onNavigate('return', { student_id: t.student_id, book_id: t.book_id })}
                          >
                            Return 📥
                          </button>
                        ) : (
                          <span style={{ fontSize: '12px', color: 'var(--color-text-dim)' }}>Completed</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
