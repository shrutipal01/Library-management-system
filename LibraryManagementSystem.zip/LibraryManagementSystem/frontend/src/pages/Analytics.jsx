import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';

export default function Analytics() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const { addToast } = useToast();

  useEffect(() => {
    loadStats();
  }, []);

  async function loadStats() {
    setLoading(true);
    try {
      const res = await api.getDashboard();
      setStats(res.data);
    } catch (err) {
      addToast('error', 'Failed to load analytics', err.message);
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <div className="loading"><div className="spinner"></div>Loading library analytics...</div>;
  if (!stats) return null;

  return (
    <div>
      <div className="page-header">
        <h1>📈 Library Analytics & Scientific Statistics</h1>
        <p>Comprehensive statistical aggregations mirroring original NumPy & Pandas data processing modules</p>
      </div>

      {/* 4.1 Numerical Statistics (NumPy Aggregations) */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-header">
          <span className="card-title">🧮 Numerical Statistics (NumPy Metrics)</span>
          <span className="badge badge-info">Aggregations & Central Tendency</span>
        </div>
        <div className="card-body">
          <div className="detail-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px' }}>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Total Unique Titles Owned</div>
              <div className="detail-value" style={{ fontSize: '20px', color: 'var(--color-primary)' }}>{stats.total_titles} titles</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Total Books Inventory Stock</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>{stats.total_books_stock} volumes</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Available on Shelves</div>
              <div className="detail-value" style={{ fontSize: '20px', color: 'var(--color-success)' }}>{stats.total_available_stock} volumes</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Currently Issued Out</div>
              <div className="detail-value" style={{ fontSize: '20px', color: 'var(--color-warning)' }}>{stats.total_currently_issued} volumes</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Registered Members</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>{stats.total_students} students</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Active Borrowers</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>{stats.active_borrowers} students</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Total Lifetime Transactions</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>{stats.total_transactions} txns</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Total Fines Collected</div>
              <div className="detail-value" style={{ fontSize: '20px', color: 'var(--color-danger)' }}>₹{stats.total_fines_collected?.toFixed(2)}</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Average Overdue Fine (NumPy)</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>₹{stats.avg_fine?.toFixed(2)}</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Maximum Overdue Fine (NumPy)</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>₹{stats.max_fine?.toFixed(2)}</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Mean Issues per Book Title</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>{stats.mean_issues_per_book?.toFixed(2)}</div>
            </div>
            <div className="detail-item" style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-sm)' }}>
              <div className="detail-label">Median Issues per Book Title</div>
              <div className="detail-value" style={{ fontSize: '20px' }}>{stats.median_issues_per_book?.toFixed(2)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* 4.2 Top 5 Most Borrowed Books (Pandas Analysis) */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div className="card-header">
          <span className="card-title">🏆 Top 5 Most Borrowed Books (Pandas Ranked Analysis)</span>
        </div>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th style={{ width: '60px' }}>Rank</th>
                <th style={{ width: '100px' }}>Book ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Genre</th>
                <th style={{ width: '120px', textAlign: 'center' }}>Total Borrow Count</th>
              </tr>
            </thead>
            <tbody>
              {stats.top_books?.map((b, idx) => (
                <tr key={b.book_id}>
                  <td style={{ fontWeight: 800, fontSize: '15px', color: idx === 0 ? '#f59e0b' : idx === 1 ? '#94a3b8' : idx === 2 ? '#b45309' : 'inherit' }}>
                    #{idx + 1}
                  </td>
                  <td className="td-mono">{b.book_id}</td>
                  <td style={{ fontWeight: 600 }}>{b.title}</td>
                  <td style={{ color: 'var(--color-text-muted)' }}>{b.author}</td>
                  <td><span className="tag">{b.genre}</span></td>
                  <td style={{ textAlign: 'center' }}>
                    <span className="badge badge-success td-mono" style={{ fontSize: '13px' }}>
                      {b.issue_count} issues
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4.3 Category & Department Breakdown */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        {/* Genre Breakdown */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">📖 Books by Genre / Subject (Pandas Distribution)</span>
          </div>
          <div className="card-body">
            <div className="chart-bar-horiz">
              {stats.genre_distribution?.map((g) => {
                const max = stats.genre_distribution[0]?.count || 1;
                const pct = Math.max(10, (g.count / max) * 100);
                return (
                  <div key={g.genre} className="chart-bar-item">
                    <span className="chart-bar-label">{g.genre}</span>
                    <div className="chart-bar-track">
                      <div className="chart-bar-fill" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #3b82f6, #8b5cf6)' }}>
                        <span className="chart-bar-value">{g.count} titles</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Department Breakdown */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">🎓 Students by Department (Pandas Distribution)</span>
          </div>
          <div className="card-body">
            <div className="chart-bar-horiz">
              {stats.dept_distribution?.map((d) => {
                const max = stats.dept_distribution[0]?.count || 1;
                const pct = Math.max(10, (d.count / max) * 100);
                return (
                  <div key={d.department} className="chart-bar-item">
                    <span className="chart-bar-label">{d.department}</span>
                    <div className="chart-bar-track">
                      <div className="chart-bar-fill" style={{ width: `${pct}%`, background: 'linear-gradient(90deg, #10b981, #06b6d4)' }}>
                        <span className="chart-bar-value">{d.count} members</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
