import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';

export default function IssueBook({ onNavigate, initialBookId }) {
  const [students, setStudents] = useState([]);
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  const [studentId, setStudentId] = useState('');
  const [bookId, setBookId] = useState(initialBookId || '');
  const [issueDate, setIssueDate] = useState(() => new Date().toISOString().split('T')[0]);

  const [submitting, setSubmitting] = useState(false);
  const [issueReceipt, setIssueReceipt] = useState(null);
  const [error, setError] = useState('');

  const { addToast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    try {
      const [stuRes, bookRes] = await Promise.all([
        api.getStudents(),
        api.getBooks({ available_only: 'true' })
      ]);
      setStudents(stuRes.data || []);
      setBooks(bookRes.data || []);
    } catch (err) {
      addToast('error', 'Failed to load options', err.message);
    } finally {
      setLoading(false);
    }
  }

  // Pre-validation checks
  const selectedStudent = students.find(s => s.student_id === studentId.trim().toUpperCase());
  const selectedBook = books.find(b => b.book_id === bookId.trim().toUpperCase());

  const studentAtLimit = selectedStudent && (selectedStudent.active_loans >= 3 || (selectedStudent.borrowed_books?.length >= 3));
  const studentAlreadyHasBook = selectedStudent && selectedStudent.borrowed_books?.includes(bookId.trim().toUpperCase());
  const bookOutOfStock = selectedBook && selectedBook.available_copies <= 0;

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setIssueReceipt(null);

    if (!studentId.trim()) return setError('Please select or enter a Student ID.');
    if (!bookId.trim()) return setError('Please select or enter a Book ID.');

    setSubmitting(true);
    try {
      const res = await api.issueBook({
        student_id: studentId.trim().toUpperCase(),
        book_id: bookId.trim().toUpperCase(),
        issue_date: issueDate
      });

      setIssueReceipt(res.data);
      addToast('success', 'Book Issued Successfully', `Issued to ${res.data.student_name}`);
      // Refresh options
      loadData();
    } catch (err) {
      setError(err.message);
      addToast('error', 'Issue Failed', err.message);
    } finally {
      setSubmitting(false);
    }
  }

  function handleReset() {
    setIssueReceipt(null);
    setStudentId('');
    setBookId('');
    setIssueDate(new Date().toISOString().split('T')[0]);
    setError('');
  }

  return (
    <div>
      <div className="page-header">
        <h1>📤 Circulation Desk — Issue Book</h1>
        <p>Issue library materials to registered members adhering to academic borrow limits and stock verification</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '24px' }}>
        {/* Left Column: Form or Receipt */}
        <div>
          {issueReceipt ? (
            /* Issue Receipt Card */
            <div className="card" style={{ borderColor: 'var(--color-primary)', boxShadow: '0 0 20px rgba(59, 130, 246, 0.2)' }}>
              <div className="card-header" style={{ borderBottom: '1px solid var(--color-border)' }}>
                <span className="card-title" style={{ color: 'var(--color-success)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>✅</span> BOOK ISSUED SUCCESSFULLY
                </span>
                <span className="badge badge-success td-mono">{issueReceipt.txn_id}</span>
              </div>
              <div className="card-body">
                <div className="detail-grid" style={{ marginBottom: '20px' }}>
                  <div className="detail-item">
                    <div className="detail-label">Transaction ID</div>
                    <div className="detail-value td-mono">{issueReceipt.txn_id}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Status</div>
                    <div className="detail-value" style={{ color: 'var(--color-info)' }}>ISSUED</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Student / Member</div>
                    <div className="detail-value">{issueReceipt.student_name}</div>
                    <div style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{issueReceipt.student_id}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Book Title</div>
                    <div className="detail-value">{issueReceipt.book_title}</div>
                    <div style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{issueReceipt.book_id}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Issue Date</div>
                    <div className="detail-value td-mono">{issueReceipt.issue_date}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Due Date</div>
                    <div className="detail-value td-mono" style={{ color: 'var(--color-warning)' }}>
                      {issueReceipt.due_date} (14 days)
                    </div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Stock Status</div>
                    <div className="detail-value">
                      {issueReceipt.remaining_copies} of {issueReceipt.total_copies} available
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button className="btn btn-primary" onClick={handleReset}>
                    Issue Another Book
                  </button>
                  <button className="btn btn-secondary" onClick={() => onNavigate('transactions')}>
                    View All Transactions →
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Issue Form */
            <div className="card">
              <div className="card-header">
                <span className="card-title">Issue Book Form</span>
              </div>
              <div className="card-body">
                {error && <div className="alert alert-error">⚠️ {error}</div>}

                <form onSubmit={handleSubmit}>
                  {/* Student Selection */}
                  <div className="form-group">
                    <label>Select Student / Member <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <select
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value)}
                        style={{ flex: 1 }}
                        id="select-issue-student"
                      >
                        <option value="">-- Choose registered student --</option>
                        {students.map(s => {
                          const loans = s.active_loans || (s.borrowed_books?.length || 0);
                          return (
                            <option key={s.student_id} value={s.student_id}>
                              {s.name} ({s.student_id}) — {loans}/3 books borrowed
                            </option>
                          );
                        })}
                      </select>
                      <input
                        type="text"
                        placeholder="Or Type ID"
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value.toUpperCase())}
                        style={{ width: '130px' }}
                      />
                    </div>
                    {selectedStudent && (
                      <div style={{ marginTop: '6px', fontSize: '12px', display: 'flex', gap: '12px' }}>
                        <span>Dept: <strong>{selectedStudent.department}</strong></span>
                        <span>Active Loans: <strong>{selectedStudent.active_loans || 0}/3</strong></span>
                      </div>
                    )}
                    {studentAtLimit && (
                      <div className="alert alert-error" style={{ marginTop: '8px', padding: '8px 12px' }}>
                        ⚠️ Maximum borrow limit reached! Student already has 3 books issued.
                      </div>
                    )}
                  </div>

                  {/* Book Selection */}
                  <div className="form-group">
                    <label>Select Book <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <select
                        value={bookId}
                        onChange={(e) => setBookId(e.target.value)}
                        style={{ flex: 1 }}
                        id="select-issue-book"
                      >
                        <option value="">-- Choose book on shelf --</option>
                        {books.map(b => (
                          <option key={b.book_id} value={b.book_id}>
                            {b.title} ({b.book_id}) — {b.available_copies} of {b.total_copies} available
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        placeholder="Or Type ID"
                        value={bookId}
                        onChange={(e) => setBookId(e.target.value.toUpperCase())}
                        style={{ width: '130px' }}
                      />
                    </div>
                    {selectedBook && (
                      <div style={{ marginTop: '6px', fontSize: '12px', display: 'flex', gap: '12px' }}>
                        <span>Author: <strong>{selectedBook.author}</strong></span>
                        <span>Genre: <strong>{selectedBook.genre}</strong></span>
                        <span>Available: <strong>{selectedBook.available_copies}/{selectedBook.total_copies}</strong></span>
                      </div>
                    )}
                    {studentAlreadyHasBook && (
                      <div className="alert alert-error" style={{ marginTop: '8px', padding: '8px 12px' }}>
                        ⚠️ Student already has an active loan of this book!
                      </div>
                    )}
                    {bookOutOfStock && (
                      <div className="alert alert-error" style={{ marginTop: '8px', padding: '8px 12px' }}>
                        ⚠️ Out of Stock! No copies currently available on shelf.
                      </div>
                    )}
                  </div>

                  {/* Issue Date */}
                  <div className="form-group">
                    <label>Issue Date</label>
                    <input
                      type="date"
                      value={issueDate}
                      onChange={(e) => setIssueDate(e.target.value)}
                      required
                      id="input-issue-date"
                    />
                    <span style={{ fontSize: '11px', color: 'var(--color-text-dim)', marginTop: '4px', display: 'block' }}>
                      Due date will automatically be set to 14 days from issue date.
                    </span>
                  </div>

                  <div style={{ marginTop: '24px' }}>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={submitting || studentAtLimit || studentAlreadyHasBook || bookOutOfStock || !studentId || !bookId}
                      style={{ width: '100%', justifyContent: 'center' }}
                      id="btn-submit-issue"
                    >
                      {submitting ? 'Issuing Book...' : '📤 Confirm Issue Book'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Circulation Rules & Quick Info */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div className="card">
            <div className="card-header">
              <span className="card-title">📋 University Loan Regulations</span>
            </div>
            <div className="card-body">
              <ul style={{ paddingLeft: '18px', margin: 0, fontSize: '13px', lineHeight: '1.7', color: 'var(--color-text-muted)' }}>
                <li><strong style={{ color: 'var(--color-text)' }}>Loan Period:</strong> Standard 14 days per loan.</li>
                <li><strong style={{ color: 'var(--color-text)' }}>Quota:</strong> Maximum 3 books active per student.</li>
                <li><strong style={{ color: 'var(--color-text)' }}>Duplicates:</strong> A student cannot borrow multiple copies of the same title.</li>
                <li><strong style={{ color: 'var(--color-text)' }}>Tier 1 Fine (1–7 days):</strong> ₹2.00 / day</li>
                <li><strong style={{ color: 'var(--color-text)' }}>Tier 2 Fine (8–14 days):</strong> ₹5.00 / day</li>
                <li><strong style={{ color: 'var(--color-text)' }}>Tier 3 Fine (&gt;14 days):</strong> ₹10.00 / day + ₹50 penalty</li>
              </ul>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title">⚡ Available Books Quick Pick</span>
            </div>
            <div className="card-body" style={{ maxHeight: '280px', overflowY: 'auto' }}>
              {books.slice(0, 6).map(b => (
                <div
                  key={b.book_id}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '8px 0',
                    borderBottom: '1px solid var(--color-border)',
                    fontSize: '12px'
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 600, color: 'var(--color-text)' }}>{b.title}</div>
                    <div className="td-mono" style={{ color: 'var(--color-text-dim)', fontSize: '11px' }}>{b.book_id} • {b.available_copies} avail</div>
                  </div>
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => setBookId(b.book_id)}
                  >
                    Select
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
