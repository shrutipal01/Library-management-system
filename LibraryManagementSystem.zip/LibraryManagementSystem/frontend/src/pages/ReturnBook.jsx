import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';

export default function ReturnBook({ onNavigate, initialStudentId, initialBookId }) {
  const [activeLoans, setActiveLoans] = useState([]);
  const [loading, setLoading] = useState(true);

  const [studentId, setStudentId] = useState(initialStudentId || '');
  const [bookId, setBookId] = useState(initialBookId || '');
  const [returnDate, setReturnDate] = useState(() => new Date().toISOString().split('T')[0]);

  const [submitting, setSubmitting] = useState(false);
  const [returnReceipt, setReturnReceipt] = useState(null);
  const [error, setError] = useState('');

  const { addToast } = useToast();

  useEffect(() => {
    loadActiveLoans();
  }, []);

  async function loadActiveLoans() {
    setLoading(true);
    try {
      const res = await api.getActiveTransactions();
      setActiveLoans(res.data || []);
    } catch (err) {
      addToast('error', 'Failed to load active loans', err.message);
    } finally {
      setLoading(false);
    }
  }

  // Find active loan matching current inputs
  const matchedLoan = activeLoans.find(
    l => l.student_id === studentId.trim().toUpperCase() && l.book_id === bookId.trim().toUpperCase()
  );

  // Live Fine Calculation Preview
  function computeFinePreview(dueDateStr, returnDateStr) {
    if (!dueDateStr || !returnDateStr) return { fine: 0, overdueDays: 0 };
    const due = new Date(dueDateStr);
    const ret = new Date(returnDateStr);
    due.setHours(0, 0, 0, 0);
    ret.setHours(0, 0, 0, 0);
    const msPerDay = 24 * 60 * 60 * 1000;
    const overdue = Math.floor((ret - due) / msPerDay);

    if (overdue <= 0) return { fine: 0, overdueDays: 0 };
    if (overdue <= 7) return { fine: overdue * 2.0, overdueDays: overdue };
    if (overdue <= 14) return { fine: (7 * 2.0) + ((overdue - 7) * 5.0), overdueDays: overdue };
    return { fine: (7 * 2.0) + (7 * 5.0) + ((overdue - 14) * 10.0) + 50.0, overdueDays: overdue };
  }

  const finePreview = matchedLoan ? computeFinePreview(matchedLoan.due_date, returnDate) : null;

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setReturnReceipt(null);

    if (!studentId.trim()) return setError('Please specify Student ID.');
    if (!bookId.trim()) return setError('Please specify Book ID.');

    setSubmitting(true);
    try {
      const res = await api.returnBook({
        student_id: studentId.trim().toUpperCase(),
        book_id: bookId.trim().toUpperCase(),
        return_date: returnDate
      });

      setReturnReceipt(res.data);
      addToast('success', 'Book Returned', `"${res.data.book_title}" returned by ${res.data.student_name}.`);
      loadActiveLoans();
    } catch (err) {
      setError(err.message);
      addToast('error', 'Return Failed', err.message);
    } finally {
      setSubmitting(false);
    }
  }

  function handleSelectLoan(loan) {
    setStudentId(loan.student_id);
    setBookId(loan.book_id);
    setError('');
    setReturnReceipt(null);
  }

  function handleReset() {
    setReturnReceipt(null);
    setStudentId('');
    setBookId('');
    setReturnDate(new Date().toISOString().split('T')[0]);
    setError('');
  }

  return (
    <div>
      <div className="page-header">
        <h1>📥 Circulation Desk — Return Book</h1>
        <p>Process book returns, calculate tiered overdue fines, and restock inventory</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: '24px', marginBottom: '30px' }}>
        {/* Left Column: Return Form or Receipt */}
        <div>
          {returnReceipt ? (
            /* Return Receipt Card */
            <div className="card" style={{ borderColor: 'var(--color-success)', boxShadow: '0 0 20px rgba(16, 185, 129, 0.2)' }}>
              <div className="card-header" style={{ borderBottom: '1px solid var(--color-border)' }}>
                <span className="card-title" style={{ color: 'var(--color-success)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span>🧾</span> OFFICIAL BOOK RETURN RECEIPT
                </span>
                <span className="badge badge-success td-mono">{returnReceipt.txn_id}</span>
              </div>
              <div className="card-body">
                <div className="detail-grid" style={{ marginBottom: '20px' }}>
                  <div className="detail-item">
                    <div className="detail-label">Transaction ID</div>
                    <div className="detail-value td-mono">{returnReceipt.txn_id}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Status</div>
                    <div className="detail-value" style={{ color: 'var(--color-success)' }}>RETURNED</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Student / Member</div>
                    <div className="detail-value">{returnReceipt.student_name}</div>
                    <div style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{returnReceipt.student_id}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Book Title</div>
                    <div className="detail-value">{returnReceipt.book_title}</div>
                    <div style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{returnReceipt.book_id}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Due Date</div>
                    <div className="detail-value td-mono">{returnReceipt.due_date}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Returned On</div>
                    <div className="detail-value td-mono">{returnReceipt.return_date}</div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Overdue Days</div>
                    <div className="detail-value" style={{ color: returnReceipt.overdue_days > 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>
                      {returnReceipt.overdue_days} day(s)
                    </div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Fine Charged</div>
                    <div className="detail-value" style={{ fontSize: '18px', fontWeight: 800, color: returnReceipt.fine_amount > 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>
                      ₹{returnReceipt.fine_amount.toFixed(2)}
                    </div>
                  </div>
                  <div className="detail-item">
                    <div className="detail-label">Restocked Inventory</div>
                    <div className="detail-value">{returnReceipt.updated_available_copies} available</div>
                  </div>
                </div>

                {returnReceipt.fine_amount > 0 ? (
                  <div className="alert alert-warning" style={{ fontSize: '12px', marginBottom: '20px' }}>
                    <strong>* Fines calculated per MCA Library Rules:</strong><br />
                    1–7 days: ₹2/day • 8–14 days: ₹5/day • &gt;14 days: ₹10/day + ₹50 penalty.
                  </div>
                ) : (
                  <div className="alert alert-info" style={{ fontSize: '12px', marginBottom: '20px' }}>
                    ✅ Book returned on or before due date. No overdue fine charged!
                  </div>
                )}

                <div style={{ display: 'flex', gap: '10px' }}>
                  <button className="btn btn-primary" onClick={handleReset}>
                    Process Another Return
                  </button>
                  <button className="btn btn-secondary" onClick={() => onNavigate('transactions')}>
                    View Transaction Log →
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Return Form */
            <div className="card">
              <div className="card-header">
                <span className="card-title">Return Book Form</span>
              </div>
              <div className="card-body">
                {error && <div className="alert alert-error">⚠️ {error}</div>}

                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label>Student ID <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                    <input
                      type="text"
                      placeholder="e.g. MCA202601"
                      value={studentId}
                      onChange={(e) => setStudentId(e.target.value.toUpperCase())}
                      required
                      id="input-return-student-id"
                    />
                  </div>

                  <div className="form-group">
                    <label>Book ID <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                    <input
                      type="text"
                      placeholder="e.g. B101"
                      value={bookId}
                      onChange={(e) => setBookId(e.target.value.toUpperCase())}
                      required
                      id="input-return-book-id"
                    />
                  </div>

                  <div className="form-group">
                    <label>Return Date</label>
                    <input
                      type="date"
                      value={returnDate}
                      onChange={(e) => setReturnDate(e.target.value)}
                      required
                      id="input-return-date"
                    />
                    <span style={{ fontSize: '11px', color: 'var(--color-text-dim)', marginTop: '4px', display: 'block' }}>
                      Defaults to today. Change date to simulate overdue or early return.
                    </span>
                  </div>

                  {/* Matched Loan Live Status */}
                  {matchedLoan ? (
                    <div style={{ background: 'var(--color-bg-secondary)', padding: '12px', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', marginBottom: '16px' }}>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--color-text)', marginBottom: '6px' }}>
                        📖 Active Loan Found: {matchedLoan.book_title}
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '12px', color: 'var(--color-text-muted)' }}>
                        <div>Borrower: <strong>{matchedLoan.student_name}</strong></div>
                        <div>Issued On: <span className="td-mono">{matchedLoan.issue_date}</span></div>
                        <div>Due Date: <span className="td-mono">{matchedLoan.due_date}</span></div>
                        <div>
                          Overdue: <strong style={{ color: finePreview?.overdueDays > 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>
                            {finePreview?.overdueDays || 0} day(s)
                          </strong>
                        </div>
                      </div>

                      <div style={{ marginTop: '10px', paddingTop: '8px', borderTop: '1px solid var(--color-border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600 }}>Calculated Fine:</span>
                        <span style={{ fontSize: '16px', fontWeight: 800, color: (finePreview?.fine || 0) > 0 ? 'var(--color-danger)' : 'var(--color-success)' }}>
                          ₹{(finePreview?.fine || 0).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  ) : studentId && bookId ? (
                    <div className="alert alert-warning" style={{ fontSize: '12px', marginBottom: '16px' }}>
                      ℹ️ Tip: Check if this Student ID and Book ID correspond to an active loan in the table below.
                    </div>
                  ) : null}

                  <div style={{ marginTop: '16px' }}>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={submitting || !studentId || !bookId}
                      style={{ width: '100%', justifyContent: 'center' }}
                      id="btn-submit-return"
                    >
                      {submitting ? 'Processing Return...' : '📥 Confirm Book Return'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Fine Calculation Breakdown Guide */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div className="card">
            <div className="card-header">
              <span className="card-title">💰 MCA Tiered Fine Policy</span>
            </div>
            <div className="card-body">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '13px' }}>
                <div style={{ padding: '10px', borderRadius: 'var(--radius-sm)', background: 'rgba(16, 185, 129, 0.1)', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                  <div style={{ fontWeight: 600, color: '#34d399' }}>On-Time Return (≤ Due Date)</div>
                  <div style={{ color: 'var(--color-text-muted)', fontSize: '12px', marginTop: '2px' }}>Fine: ₹0.00 — No charge</div>
                </div>

                <div style={{ padding: '10px', borderRadius: 'var(--radius-sm)', background: 'rgba(59, 130, 246, 0.1)', border: '1px solid rgba(59, 130, 246, 0.2)' }}>
                  <div style={{ fontWeight: 600, color: '#60a5fa' }}>Tier 1 (1 to 7 Days Overdue)</div>
                  <div style={{ color: 'var(--color-text-muted)', fontSize: '12px', marginTop: '2px' }}>Rate: ₹2.00 per day</div>
                </div>

                <div style={{ padding: '10px', borderRadius: 'var(--radius-sm)', background: 'rgba(245, 158, 11, 0.1)', border: '1px solid rgba(245, 158, 11, 0.2)' }}>
                  <div style={{ fontWeight: 600, color: '#fbbf24' }}>Tier 2 (8 to 14 Days Overdue)</div>
                  <div style={{ color: 'var(--color-text-muted)', fontSize: '12px', marginTop: '2px' }}>Rate: (7 × ₹2) + ((days - 7) × ₹5.00)</div>
                </div>

                <div style={{ padding: '10px', borderRadius: 'var(--radius-sm)', background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
                  <div style={{ fontWeight: 600, color: '#f87171' }}>Tier 3 (&gt; 14 Days Overdue)</div>
                  <div style={{ color: 'var(--color-text-muted)', fontSize: '12px', marginTop: '2px' }}>Rate: (7 × ₹2) + (7 × ₹5) + ((days - 14) × ₹10.00) + ₹50 Penalty</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Active Loans Quick Return Table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">
            🔄 Active Unreturned Loans ({activeLoans.length}) — Click 'Select' for 1-Click Return
          </span>
        </div>
        {loading ? (
          <div className="loading"><div className="spinner"></div>Loading active loans...</div>
        ) : activeLoans.length === 0 ? (
          <div className="empty-state">
            <p>No active loans currently in circulation.</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Txn ID</th>
                  <th>Book Title</th>
                  <th>Student Name</th>
                  <th>Issue Date</th>
                  <th>Due Date</th>
                  <th>Status</th>
                  <th style={{ width: '120px', textAlign: 'right' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {activeLoans.map((loan) => {
                  const today = new Date().toISOString().split('T')[0];
                  const isOverdue = loan.due_date < today;
                  return (
                    <tr key={loan.txn_id} style={{ background: loan.txn_id === matchedLoan?.txn_id ? 'rgba(59, 130, 246, 0.08)' : 'transparent' }}>
                      <td className="td-mono">{loan.txn_id}</td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{loan.book_title}</div>
                        <div className="td-mono" style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{loan.book_id}</div>
                      </td>
                      <td>
                        <div>{loan.student_name}</div>
                        <div className="td-mono" style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{loan.student_id}</div>
                      </td>
                      <td className="td-mono">{loan.issue_date}</td>
                      <td className="td-mono" style={{ color: isOverdue ? 'var(--color-danger)' : 'inherit', fontWeight: isOverdue ? 700 : 'normal' }}>
                        {loan.due_date}
                      </td>
                      <td>
                        <span className={`badge ${isOverdue ? 'badge-danger' : 'badge-issued'}`}>
                          {isOverdue ? '⚠️ OVERDUE' : 'ON LOAN'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => handleSelectLoan(loan)}
                        >
                          Select 📥
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
