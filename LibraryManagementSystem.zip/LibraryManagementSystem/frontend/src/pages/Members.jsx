import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';
import ConfirmDialog from '../components/ConfirmDialog';

const NAME_VALIDATION_MESSAGE = 'Name can only contain letters and spaces.';

function isValidStudentName(name) {
  return /^[\p{L} ]+$/u.test(name.trim());
}

export default function Members({ onNavigate }) {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [deletingStudent, setDeletingStudent] = useState(null);
  const [historyStudent, setHistoryStudent] = useState(null);
  const [studentHistory, setStudentHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // Form states
  const [formData, setFormData] = useState({
    student_id: '',
    name: '',
    department: 'MCA',
    contact: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [nameError, setNameError] = useState('');

  const { addToast } = useToast();

  function handleNameChange(value) {
    setFormData({ ...formData, name: value });
    setNameError(value.trim() && !isValidStudentName(value) ? NAME_VALIDATION_MESSAGE : '');
  }

  useEffect(() => {
    loadStudents();
  }, [search]);

  async function loadStudents() {
    setLoading(true);
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      const res = await api.getStudents(params);
      setStudents(res.data || []);
    } catch (err) {
      addToast('error', 'Failed to load students', err.message);
    } finally {
      setLoading(false);
    }
  }

  function handleOpenAdd() {
    setFormData({
      student_id: '',
      name: '',
      department: 'MCA',
      contact: ''
    });
    setFormError('');
    setNameError('');
    setShowAddModal(true);
  }

  function handleOpenEdit(student) {
    setEditingStudent(student);
    setFormData({
      student_id: student.student_id,
      name: student.name,
      department: student.department,
      contact: student.contact
    });
    setFormError('');
    setNameError('');
  }

  async function handleOpenHistory(student) {
    setHistoryStudent(student);
    setLoadingHistory(true);
    try {
      const res = await api.getStudentHistory(student.student_id);
      setStudentHistory(res.data || []);
    } catch (err) {
      addToast('error', 'Failed to load history', err.message);
    } finally {
      setLoadingHistory(false);
    }
  }

  async function handleAddSubmit(e) {
    e.preventDefault();
    setFormError('');
    if (!formData.student_id.trim()) return setFormError('Student ID is required.');
    if (!formData.name.trim()) return setFormError('Name is required.');
    if (!isValidStudentName(formData.name)) {
      setNameError(NAME_VALIDATION_MESSAGE);
      return;
    }

    setSubmitting(true);
    try {
      await api.addStudent(formData);
      addToast('success', 'Student Registered', `"${formData.name}" has been registered.`);
      setShowAddModal(false);
      loadStudents();
    } catch (err) {
      setFormError(err.message);
      addToast('error', 'Registration Failed', err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleEditSubmit(e) {
    e.preventDefault();
    setFormError('');
    if (!formData.name.trim()) return setFormError('Name is required.');
    if (!isValidStudentName(formData.name)) {
      setNameError(NAME_VALIDATION_MESSAGE);
      return;
    }

    setSubmitting(true);
    try {
      await api.updateStudent(editingStudent.student_id, formData);
      addToast('success', 'Student Updated', `"${formData.name}" updated successfully.`);
      setEditingStudent(null);
      loadStudents();
    } catch (err) {
      setFormError(err.message);
      addToast('error', 'Update Failed', err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDeleteConfirm() {
    if (!deletingStudent) return;
    try {
      await api.deleteStudent(deletingStudent.student_id);
      addToast('success', 'Member Removed', `"${deletingStudent.name}" removed from registry.`);
      setDeletingStudent(null);
      loadStudents();
    } catch (err) {
      addToast('error', 'Deletion Blocked', err.message);
      setDeletingStudent(null);
    }
  }

  return (
    <div>
      {/* Header */}
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>👥 Student / Member Directory</h1>
          <p>Register members, inspect active loans, borrowing limits (max 3 books), and loan history</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd} id="btn-register-student">
          ➕ Register New Student
        </button>
      </div>

      {/* Search Toolbar */}
      <div className="card" style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <div style={{ flex: '1 1 300px' }}>
            <input
              type="text"
              placeholder="Search by student name, roll number / ID, or department..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              id="input-member-search"
            />
          </div>
          <span style={{ fontSize: '13px', color: 'var(--color-text-dim)' }}>
            Total: {students.length} members
          </span>
        </div>
      </div>

      {/* Students Table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Registered Library Members</span>
        </div>

        {loading ? (
          <div className="loading"><div className="spinner"></div>Loading members...</div>
        ) : students.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">👥</div>
            <h3>No students found</h3>
            <p>Try searching for a different keyword or register a new student.</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th style={{ width: '130px' }}>Student ID</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Contact</th>
                  <th style={{ width: '110px', textAlign: 'center' }}>Active Loans</th>
                  <th>Holding Books</th>
                  <th style={{ width: '200px', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => {
                  const loanCount = student.active_loans || (student.borrowed_books?.length || 0);
                  const atLimit = loanCount >= 3;
                  return (
                    <tr key={student.student_id}>
                      <td className="td-mono">{student.student_id}</td>
                      <td>
                        <div style={{ fontWeight: 600, color: 'var(--color-text)' }}>{student.name}</div>
                      </td>
                      <td>
                        <span className="tag">{student.department}</span>
                      </td>
                      <td style={{ color: 'var(--color-text-muted)' }}>{student.contact}</td>
                      <td style={{ textAlign: 'center' }}>
                        <span
                          className={`badge ${atLimit ? 'badge-danger' : loanCount > 0 ? 'badge-warning' : 'badge-neutral'}`}
                          title={atLimit ? 'Maximum borrow limit reached (3/3)' : `${loanCount} active loans`}
                        >
                          {loanCount} / 3
                        </span>
                      </td>
                      <td>
                        {student.borrowed_books && student.borrowed_books.length > 0 ? (
                          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                            {student.borrowed_books.map((bId) => (
                              <span key={bId} className="td-mono" style={{ fontSize: '11px', background: 'rgba(59, 130, 246, 0.1)', color: '#60a5fa', padding: '2px 6px', borderRadius: '4px' }}>
                                {bId}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span style={{ color: 'var(--color-text-dim)', fontSize: '12px' }}>None</span>
                        )}
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <div style={{ display: 'flex', gap: '6px', justifyContent: 'flex-end' }}>
                          <button
                            className="btn btn-ghost btn-sm"
                            title="View borrowing history"
                            onClick={() => handleOpenHistory(student)}
                          >
                            📜 History
                          </button>
                          <button
                            className="btn btn-secondary btn-sm"
                            title="Edit student"
                            onClick={() => handleOpenEdit(student)}
                          >
                            ✏️ Edit
                          </button>
                          <button
                            className="btn btn-danger btn-sm"
                            title="Remove student"
                            onClick={() => setDeletingStudent(student)}
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Register Student Modal */}
      {showAddModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2 className="modal-title">➕ Register New Student</h2>
              <button className="modal-close" onClick={() => setShowAddModal(false)}>✕</button>
            </div>
            {formError && <div className="alert alert-error">⚠️ {formError}</div>}
            <form onSubmit={handleAddSubmit}>
              <div className="form-group">
                <label>Student ID / Roll No <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  placeholder="e.g. MCA202610"
                  value={formData.student_id}
                  onChange={(e) => setFormData({ ...formData, student_id: e.target.value.toUpperCase() })}
                  required
                  id="input-add-student-id"
                />
              </div>
              <div className="form-group">
                <label>Full Name <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  placeholder="Student complete name"
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  aria-invalid={Boolean(nameError)}
                  aria-describedby={nameError ? 'input-add-student-name-error' : undefined}
                  required
                  id="input-add-student-name"
                />
                {nameError && <small id="input-add-student-name-error" role="alert" style={{ color: 'var(--color-danger)' }}>{nameError}</small>}
              </div>
              <div className="form-group">
                <label>Department</label>
                <input
                  type="text"
                  placeholder="e.g. MCA, MSc CS, MTech"
                  value={formData.department}
                  onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  id="input-add-student-dept"
                />
              </div>
              <div className="form-group">
                <label>Contact (Email or Phone)</label>
                <input
                  type="text"
                  placeholder="student@university.edu or phone number"
                  value={formData.contact}
                  onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                  id="input-add-student-contact"
                />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting} id="btn-submit-register-student">
                  {submitting ? 'Registering...' : 'Register Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Student Modal */}
      {editingStudent && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2 className="modal-title">✏️ Edit Student ({editingStudent.student_id})</h2>
              <button className="modal-close" onClick={() => setEditingStudent(null)}>✕</button>
            </div>
            {formError && <div className="alert alert-error">⚠️ {formError}</div>}
            <form onSubmit={handleEditSubmit}>
              <div className="form-group">
                <label>Student ID</label>
                <input type="text" value={formData.student_id} disabled style={{ opacity: 0.6, cursor: 'not-allowed' }} />
              </div>
              <div className="form-group">
                <label>Full Name <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  aria-invalid={Boolean(nameError)}
                  aria-describedby={nameError ? 'input-edit-student-name-error' : undefined}
                  required
                  id="input-edit-student-name"
                />
                {nameError && <small id="input-edit-student-name-error" role="alert" style={{ color: 'var(--color-danger)' }}>{nameError}</small>}
              </div>
              <div className="form-group">
                <label>Department</label>
                <input
                  type="text"
                  value={formData.department}
                  onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Contact</label>
                <input
                  type="text"
                  value={formData.contact}
                  onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setEditingStudent(null)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Borrowing History Modal */}
      {historyStudent && (
        <div className="modal-overlay">
          <div className="modal" style={{ maxWidth: '750px' }}>
            <div className="modal-header">
              <h2 className="modal-title">
                📜 Borrowing History: {historyStudent.name} ({historyStudent.student_id})
              </h2>
              <button className="modal-close" onClick={() => setHistoryStudent(null)}>✕</button>
            </div>

            <div style={{ marginBottom: '14px', fontSize: '13px', color: 'var(--color-text-muted)' }}>
              Department: <strong style={{ color: 'var(--color-text)' }}>{historyStudent.department}</strong> |
              Contact: <strong style={{ color: 'var(--color-text)' }}>{historyStudent.contact}</strong>
            </div>

            {loadingHistory ? (
              <div className="loading"><div className="spinner"></div>Loading history records...</div>
            ) : studentHistory.length === 0 ? (
              <div className="empty-state">
                <p>No transaction history found for this student.</p>
              </div>
            ) : (
              <div className="table-wrapper" style={{ maxHeight: '350px', overflowY: 'auto' }}>
                <table>
                  <thead>
                    <tr>
                      <th>Txn ID</th>
                      <th>Book</th>
                      <th>Issue Date</th>
                      <th>Due Date</th>
                      <th>Status</th>
                      <th>Fine (INR)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {studentHistory.map((t) => (
                      <tr key={t.txn_id}>
                        <td className="td-mono">{t.txn_id}</td>
                        <td>
                          <div style={{ fontWeight: 600 }}>{t.book_title}</div>
                          <div className="td-mono" style={{ fontSize: '11px', color: 'var(--color-text-dim)' }}>{t.book_id}</div>
                        </td>
                        <td className="td-mono">{t.issue_date}</td>
                        <td className="td-mono">{t.due_date}</td>
                        <td>
                          <span className={`badge ${t.status === 'ISSUED' ? 'badge-issued' : 'badge-returned'}`}>
                            {t.status}
                          </span>
                        </td>
                        <td style={{ color: t.fine_amount > 0 ? 'var(--color-danger)' : 'var(--color-text)' }}>
                          ₹{t.fine_amount ? t.fine_amount.toFixed(2) : '0.00'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="modal-actions" style={{ marginTop: '16px' }}>
              <button className="btn btn-secondary" onClick={() => setHistoryStudent(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!deletingStudent}
        title="Remove Member"
        message={`Are you sure you want to remove "${deletingStudent?.name}" (${deletingStudent?.student_id}) from the library records?`}
        confirmText="Remove Member"
        confirmClass="btn-danger"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeletingStudent(null)}
      />
    </div>
  );
}
