import { useState, useEffect, useMemo } from 'react';
import { api } from '../services/api';
import { useToast } from '../hooks/useToast';
import ConfirmDialog from '../components/ConfirmDialog';

export default function Books({ onNavigate }) {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [searchBy, setSearchBy] = useState('all');
  const [availableOnly, setAvailableOnly] = useState(false);
  const [sortBy, setSortBy] = useState('title');
  const [sortOrder, setSortOrder] = useState('asc');
  const [useBubbleSort, setUseBubbleSort] = useState(false);

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingBook, setEditingBook] = useState(null);
  const [deletingBook, setDeletingBook] = useState(null);

  // Form states
  const [formData, setFormData] = useState({
    book_id: '',
    title: '',
    author: '',
    genre: '',
    total_copies: 1
  });
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  const { addToast } = useToast();

  useEffect(() => {
    loadBooks();
  }, [search, searchBy, availableOnly, sortBy, sortOrder]);

  async function loadBooks() {
    setLoading(true);
    try {
      const params = {};
      if (search.trim()) {
        params.search = search.trim();
        params.search_by = searchBy;
      }
      if (availableOnly) {
        params.available_only = 'true';
      }
      params.sort_by = sortBy;
      params.order = sortOrder;

      const res = await api.getBooks(params);
      let data = res.data || [];

      // If user enabled custom Bubble Sort algorithm in UI (Syllabus Demonstration)
      if (useBubbleSort) {
        data = bubbleSort(data, sortBy, sortOrder === 'desc');
      }

      setBooks(data);
    } catch (err) {
      addToast('error', 'Failed to load books', err.message);
    } finally {
      setLoading(false);
    }
  }

  // Custom Bubble Sort Algorithm (exact port of Python Library.bubble_sort_books)
  function bubbleSort(items, key, reverse = false) {
    const arr = [...items];
    const n = arr.length;
    for (let i = 0; i < n; i++) {
      let swapped = false;
      for (let j = 0; j < n - i - 1; j++) {
        let v1 = arr[j][key];
        let v2 = arr[j + 1][key];

        if (typeof v1 === 'string') v1 = v1.toLowerCase();
        if (typeof v2 === 'string') v2 = v2.toLowerCase();

        const cond = reverse ? v1 < v2 : v1 > v2;
        if (cond) {
          const temp = arr[j];
          arr[j] = arr[j + 1];
          arr[j + 1] = temp;
          swapped = true;
        }
      }
      if (!swapped) break;
    }
    return arr;
  }

  function handleOpenAdd() {
    setFormData({
      book_id: '',
      title: '',
      author: '',
      genre: 'Computer Science',
      total_copies: 1
    });
    setFormError('');
    setShowAddModal(true);
  }

  function handleOpenEdit(book) {
    setEditingBook(book);
    setFormData({
      book_id: book.book_id,
      title: book.title,
      author: book.author,
      genre: book.genre,
      total_copies: book.total_copies
    });
    setFormError('');
  }

  async function handleAddSubmit(e) {
    e.preventDefault();
    setFormError('');
    if (!formData.book_id.trim()) return setFormError('Book ID is required.');
    if (!formData.title.trim()) return setFormError('Title is required.');
    if (!formData.author.trim()) return setFormError('Author is required.');
    if (parseInt(formData.total_copies) < 1) return setFormError('Total copies must be at least 1.');

    setSubmitting(true);
    try {
      await api.addBook(formData);
      addToast('success', 'Book Added', `"${formData.title}" added to catalog.`);
      setShowAddModal(false);
      loadBooks();
    } catch (err) {
      setFormError(err.message);
      addToast('error', 'Add Failed', err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleEditSubmit(e) {
    e.preventDefault();
    setFormError('');
    if (!formData.title.trim()) return setFormError('Title is required.');
    if (!formData.author.trim()) return setFormError('Author is required.');
    if (parseInt(formData.total_copies) < 1) return setFormError('Total copies must be at least 1.');

    setSubmitting(true);
    try {
      await api.updateBook(editingBook.book_id, formData);
      addToast('success', 'Book Updated', `"${formData.title}" updated successfully.`);
      setEditingBook(null);
      loadBooks();
    } catch (err) {
      setFormError(err.message);
      addToast('error', 'Update Failed', err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDeleteConfirm() {
    if (!deletingBook) return;
    try {
      await api.deleteBook(deletingBook.book_id);
      addToast('success', 'Book Deleted', `"${deletingBook.title}" removed from catalog.`);
      setDeletingBook(null);
      loadBooks();
    } catch (err) {
      addToast('error', 'Delete Failed', err.message);
      setDeletingBook(null);
    }
  }

  return (
    <div>
      {/* Header */}
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>📚 Book Management</h1>
          <p>Catalog operations: browse, search, sort, add, edit, and manage library inventory</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd} id="btn-add-book">
          ➕ Add New Book
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="card" style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
          {/* Search input */}
          <div style={{ flex: '1 1 240px', minWidth: '220px' }}>
            <input
              type="text"
              placeholder="Search by title, author, genre, or ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              id="input-book-search"
            />
          </div>

          {/* Search By */}
          <div style={{ width: '130px' }}>
            <select value={searchBy} onChange={(e) => setSearchBy(e.target.value)} id="select-search-by">
              <option value="all">All Fields</option>
              <option value="title">Title</option>
              <option value="author">Author</option>
              <option value="genre">Genre</option>
            </select>
          </div>

          {/* Sort By */}
          <div style={{ width: '160px' }}>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} id="select-sort-by">
              <option value="title">Sort: Title</option>
              <option value="author">Sort: Author</option>
              <option value="issue_count">Sort: Most Issued</option>
              <option value="available_copies">Sort: Available Stock</option>
              <option value="book_id">Sort: Book ID</option>
            </select>
          </div>

          {/* Order */}
          <div style={{ width: '100px' }}>
            <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value)} id="select-sort-order">
              <option value="asc">Asc ⬆️</option>
              <option value="desc">Desc ⬇️</option>
            </select>
          </div>

          {/* Available Only Filter */}
          <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', cursor: 'pointer', userSelect: 'none' }}>
            <input
              type="checkbox"
              checked={availableOnly}
              onChange={(e) => setAvailableOnly(e.target.checked)}
              id="checkbox-available-only"
            />
            Available on Shelf Only
          </label>

          {/* Algorithm Toggle (Bubble Sort vs Standard) */}
          <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', cursor: 'pointer', userSelect: 'none', marginLeft: 'auto', background: 'var(--color-bg-secondary)', padding: '6px 12px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border)' }}>
            <input
              type="checkbox"
              checked={useBubbleSort}
              onChange={(e) => {
                setUseBubbleSort(e.target.checked);
                if (!e.target.checked) loadBooks();
                else setBooks(prev => bubbleSort(prev, sortBy, sortOrder === 'desc'));
              }}
              id="checkbox-bubble-sort"
            />
            <span>Custom Bubble Sort {useBubbleSort ? '⚡ (Active)' : ''}</span>
          </label>
        </div>
      </div>

      {/* Books Table */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">
            Catalog Inventory ({books.length} {books.length === 1 ? 'book' : 'books'})
          </span>
          {useBubbleSort && (
            <span className="badge badge-info">Algorithm: Custom Bubble Sort</span>
          )}
        </div>

        {loading ? (
          <div className="loading"><div className="spinner"></div>Loading catalog...</div>
        ) : books.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📚</div>
            <h3>No books found</h3>
            <p>Try clearing your search query or add a new book to the catalog.</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th style={{ width: '90px' }}>Book ID</th>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Genre</th>
                  <th style={{ width: '120px' }}>Stock</th>
                  <th style={{ width: '80px', textAlign: 'center' }}>Issues</th>
                  <th style={{ width: '110px' }}>Status</th>
                  <th style={{ width: '180px', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {books.map((book) => {
                  const isAvail = book.available_copies > 0;
                  return (
                    <tr key={book.book_id}>
                      <td className="td-mono">{book.book_id}</td>
                      <td>
                        <div style={{ fontWeight: 600, color: 'var(--color-text)' }}>{book.title}</div>
                      </td>
                      <td style={{ color: 'var(--color-text-muted)' }}>{book.author}</td>
                      <td>
                        <span className="tag">{book.genre}</span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span style={{ fontWeight: 600 }}>{book.available_copies}</span>
                          <span style={{ color: 'var(--color-text-dim)' }}>/ {book.total_copies}</span>
                        </div>
                        <div className="progress-bar" style={{ height: '4px', marginTop: '4px' }}>
                          <div
                            className="progress-bar-fill"
                            style={{
                              width: `${(book.available_copies / book.total_copies) * 100}%`,
                              background: isAvail ? 'var(--color-success)' : 'var(--color-danger)'
                            }}
                          />
                        </div>
                      </td>
                      <td style={{ textAlign: 'center', fontWeight: 600 }}>{book.issue_count}</td>
                      <td>
                        <span className={`badge ${isAvail ? 'badge-available' : 'badge-unavailable'}`}>
                          {isAvail ? 'In Stock' : 'Out of Stock'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <div style={{ display: 'flex', gap: '6px', justifyContent: 'flex-end' }}>
                          {isAvail && (
                            <button
                              className="btn btn-ghost btn-sm"
                              title="Issue this book"
                              onClick={() => {
                                if (onNavigate) onNavigate('issue', { book_id: book.book_id });
                              }}
                            >
                              📤 Issue
                            </button>
                          )}
                          <button
                            className="btn btn-secondary btn-sm"
                            title="Edit book details"
                            onClick={() => handleOpenEdit(book)}
                          >
                            ✏️ Edit
                          </button>
                          <button
                            className="btn btn-danger btn-sm"
                            title="Delete book"
                            onClick={() => setDeletingBook(book)}
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Book Modal */}
      {showAddModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2 className="modal-title">➕ Add New Book to Catalog</h2>
              <button className="modal-close" onClick={() => setShowAddModal(false)}>✕</button>
            </div>
            {formError && <div className="alert alert-error">⚠️ {formError}</div>}
            <form onSubmit={handleAddSubmit}>
              <div className="form-group">
                <label>Book ID <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  placeholder="e.g. B113"
                  value={formData.book_id}
                  onChange={(e) => setFormData({ ...formData, book_id: e.target.value.toUpperCase() })}
                  required
                  id="input-add-book-id"
                />
              </div>
              <div className="form-group">
                <label>Book Title <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  placeholder="Enter complete book title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  id="input-add-book-title"
                />
              </div>
              <div className="form-group">
                <label>Author <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  placeholder="Author / Editor name"
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  required
                  id="input-add-book-author"
                />
              </div>
              <div className="form-group">
                <label>Genre / Category</label>
                <input
                  type="text"
                  placeholder="e.g. Computer Science, AI & ML, Web Dev"
                  value={formData.genre}
                  onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                  id="input-add-book-genre"
                />
              </div>
              <div className="form-group">
                <label>Total Copies <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="number"
                  min="1"
                  value={formData.total_copies}
                  onChange={(e) => setFormData({ ...formData, total_copies: parseInt(e.target.value) || 1 })}
                  required
                  id="input-add-book-copies"
                />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting} id="btn-submit-add-book">
                  {submitting ? 'Adding...' : 'Add Book'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Book Modal */}
      {editingBook && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2 className="modal-title">✏️ Edit Book ({editingBook.book_id})</h2>
              <button className="modal-close" onClick={() => setEditingBook(null)}>✕</button>
            </div>
            {formError && <div className="alert alert-error">⚠️ {formError}</div>}
            <form onSubmit={handleEditSubmit}>
              <div className="form-group">
                <label>Book ID</label>
                <input type="text" value={formData.book_id} disabled style={{ opacity: 0.6, cursor: 'not-allowed' }} />
              </div>
              <div className="form-group">
                <label>Book Title <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Author <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="text"
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Genre / Category</label>
                <input
                  type="text"
                  value={formData.genre}
                  onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Total Copies <span style={{ color: 'var(--color-danger)' }}>*</span></label>
                <input
                  type="number"
                  min="1"
                  value={formData.total_copies}
                  onChange={(e) => setFormData({ ...formData, total_copies: parseInt(e.target.value) || 1 })}
                  required
                />
                <span style={{ fontSize: '11px', color: 'var(--color-text-dim)', marginTop: '4px', display: 'block' }}>
                  Currently issued copies: {editingBook.total_copies - editingBook.available_copies}
                </span>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setEditingBook(null)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!deletingBook}
        title="Delete Book"
        message={`Are you sure you want to permanently delete "${deletingBook?.title}" (${deletingBook?.book_id})? This action cannot be undone.`}
        confirmText="Delete Book"
        confirmClass="btn-danger"
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeletingBook(null)}
      />
    </div>
  );
}
