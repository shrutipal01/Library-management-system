export default function Sidebar({ activePage, onNavigate, overdueCount = 0 }) {
  const navItems = [
    { id: 'dashboard', icon: '📊', label: 'Dashboard', section: 'OVERVIEW' },
    { id: 'books', icon: '📚', label: 'Books', section: 'CATALOG' },
    { id: 'members', icon: '👥', label: 'Members', section: 'CATALOG' },
    { id: 'issue', icon: '📤', label: 'Issue Book', section: 'CIRCULATION' },
    { id: 'return', icon: '📥', label: 'Return Book', section: 'CIRCULATION' },
    { id: 'transactions', icon: '🔄', label: 'Transactions', section: 'CIRCULATION' },
    { id: 'analytics', icon: '📈', label: 'Analytics', section: 'REPORTS' },
    { id: 'diagnostics', icon: '🧪', label: 'Diagnostics & Seed', section: 'SYSTEM' },
  ];

  const sections = ['OVERVIEW', 'CATALOG', 'CIRCULATION', 'REPORTS', 'SYSTEM'];
  let lastSection = null;

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon">📖</div>
        <h1>Library Management System</h1>
        <p>Central University MCA Library</p>
      </div>

      <nav className="sidebar-nav">
        {navItems.map(item => {
          const showLabel = item.section !== lastSection;
          if (showLabel) lastSection = item.section;
          return (
            <div key={item.id}>
              {showLabel && <div className="nav-section-label">{item.section}</div>}
              <button
                className={`nav-item ${activePage === item.id ? 'active' : ''}`}
                onClick={() => onNavigate(item.id)}
                id={`nav-${item.id}`}
              >
                <span className="nav-icon">{item.icon}</span>
                {item.label}
                {item.id === 'transactions' && overdueCount > 0 && (
                  <span className="nav-badge">{overdueCount}</span>
                )}
              </button>
            </div>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        MCA17400 — Python Project<br />
        v2.0 Web Edition
      </div>
    </aside>
  );
}
