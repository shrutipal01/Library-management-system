import { useState, useEffect } from 'react';
import { ToastProvider } from './hooks/useToast';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Books from './pages/Books';
import Members from './pages/Members';
import IssueBook from './pages/IssueBook';
import ReturnBook from './pages/ReturnBook';
import Transactions from './pages/Transactions';
import Analytics from './pages/Analytics';
import Diagnostics from './pages/Diagnostics';
import { api } from './services/api';

function AppContent() {
  const [activePage, setActivePage] = useState('dashboard');
  const [pageParams, setPageParams] = useState({});
  const [overdueCount, setOverdueCount] = useState(0);

  useEffect(() => {
    fetchOverdueBadge();
  }, [activePage]);

  async function fetchOverdueBadge() {
    try {
      const res = await api.getDashboard();
      if (res?.data?.overdue_count !== undefined) {
        setOverdueCount(res.data.overdue_count);
      }
    } catch {
      // silently ignore for badge polling
    }
  }

  function handleNavigate(page, params = {}) {
    setActivePage(page);
    setPageParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div className="app-container">
      <Sidebar
        activePage={activePage}
        onNavigate={handleNavigate}
        overdueCount={overdueCount}
      />
      <main className="main-content">
        {activePage === 'dashboard' && <Dashboard onNavigate={handleNavigate} />}
        {activePage === 'books' && <Books onNavigate={handleNavigate} />}
        {activePage === 'members' && <Members onNavigate={handleNavigate} />}
        {activePage === 'issue' && (
          <IssueBook
            onNavigate={handleNavigate}
            initialBookId={pageParams.book_id}
          />
        )}
        {activePage === 'return' && (
          <ReturnBook
            onNavigate={handleNavigate}
            initialStudentId={pageParams.student_id}
            initialBookId={pageParams.book_id}
          />
        )}
        {activePage === 'transactions' && <Transactions onNavigate={handleNavigate} />}
        {activePage === 'analytics' && <Analytics onNavigate={handleNavigate} />}
        {activePage === 'diagnostics' && <Diagnostics onNavigate={handleNavigate} />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppContent />
    </ToastProvider>
  );
}
