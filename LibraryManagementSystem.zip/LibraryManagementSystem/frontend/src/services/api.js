/**
 * API Service Layer
 * All calls go through Vite proxy to http://localhost:5000/api
 */

const BASE = '/api';

async function request(method, endpoint, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(`${BASE}${endpoint}`, opts);
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}

// ── BOOKS ─────────────────────────────────────
export const api = {
  // Books
  getBooks: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request('GET', `/books${q ? '?' + q : ''}`);
  },
  getBook: (id) => request('GET', `/books/${id}`),
  addBook: (data) => request('POST', '/books', data),
  updateBook: (id, data) => request('PUT', `/books/${id}`, data),
  deleteBook: (id) => request('DELETE', `/books/${id}`),

  // Students
  getStudents: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request('GET', `/students${q ? '?' + q : ''}`);
  },
  getStudent: (id) => request('GET', `/students/${id}`),
  addStudent: (data) => request('POST', '/students', data),
  updateStudent: (id, data) => request('PUT', `/students/${id}`, data),
  deleteStudent: (id) => request('DELETE', `/students/${id}`),
  getStudentHistory: (id) => request('GET', `/students/${id}/history`),

  // Transactions
  getTransactions: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request('GET', `/transactions${q ? '?' + q : ''}`);
  },
  getActiveTransactions: () => request('GET', '/transactions/active'),
  issueBook: (data) => request('POST', '/transactions/issue', data),
  returnBook: (data) => request('POST', '/transactions/return', data),

  // Dashboard
  getDashboard: () => request('GET', '/dashboard'),

  // System
  getDiagnostics: () => request('GET', '/system/diagnostics'),
  resetDatabase: () => request('POST', '/system/reset'),
};
